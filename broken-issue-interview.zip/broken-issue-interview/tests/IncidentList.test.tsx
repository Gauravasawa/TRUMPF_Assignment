import { render, screen } from "@testing-library/react";
import { vi, describe, it, expect } from "vitest";
import { IncidentList } from "../src/components/IncidentList";
import { useIncidentsStore } from "../src/state/incidentsStore";

vi.mock("../src/state/incidentsStore", () => ({
  useIncidentsStore: vi.fn(),
}));

describe("IncidentList", () => {
  it("renders incidents from the store", () => {
    const testIncidents = [
      {
        id: "232",
        title: "Incident #232",
        severity: "low",
        timestamp: "2026-01-27T03:47:56.225Z",
        description: "test incident",
      },
      {
        id: "265",
        title: "Incident #265",
        severity: "medium",
        timestamp: "2026-01-28T01:07:10.822Z",
        description: "",
      },
    ];

    (useIncidentsStore as any).mockImplementation((selector: any) =>
      selector({
        filteredIncidents: () => testIncidents,
        selectedId: null,
        selectIncident: vi.fn(),
      }),
    );

    render(<IncidentList />);

    const items = screen.getAllByRole("listitem");
    expect(items.length).toBe(2);
    expect(screen.getByText("Incident #232")).toBeTruthy();
  });
});

// Dashboard.test.tsx
import { render, screen } from "@testing-library/react";
import { describe, it, expect } from "vitest";
import { Dashboard } from "../src/pages/Dashboard";

//check for the filter heading is rendering
describe("Dashboard", () => {
  it("renders filters heading", () => {
    render(<Dashboard />);
    expect(screen.getByText("Filters")).toBeInTheDocument();
  });

  it("renders incident list section", () => {
    render(<Dashboard />);
    expect(screen.getByRole("list")).toBeInTheDocument();
  });
});

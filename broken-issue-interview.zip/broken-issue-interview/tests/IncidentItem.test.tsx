import { render, screen, fireEvent } from "@testing-library/react";
import { expect, vi, it } from "vitest";
import { IncidentItem } from "../src/components/IncidentItem";

it("onClick is cliked", () => {
  const mockOnClick = vi.fn();
  const mockIncident = {
    id: "138",
    title: "Incident #138",
    severity: "critical",
    timestamp: "2026-01-26T00:09:45.575Z",
    description: "Test",
  };

  render(
    <IncidentItem
      incident={mockIncident}
      onClick={mockOnClick}
      severityClass={() => "test-class"}
    />,
  );

  fireEvent.click(screen.getByText("Incident #138"));
  expect(mockOnClick).toHaveBeenCalledTimes(1);
});

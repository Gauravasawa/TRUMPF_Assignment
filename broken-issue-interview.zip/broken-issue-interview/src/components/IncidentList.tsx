import React from "react";
import { useIncidentsStore } from "../state/incidentsStore";
import { IncidentItem } from "./IncidentItem";
import Modal from "react-responsive-modal";
import "react-responsive-modal/styles.css";
import type { Severity } from "../api/incidents";

export const IncidentList: React.FC = () => {
  const incidents = useIncidentsStore((s) => s.filteredIncidents());
  const selectIncident = useIncidentsStore((s) => s.selectIncident);
  const selectedId = useIncidentsStore((s) => s.selectedId);

  const selectedIncident = (incidents || []).find(
    (incident) => incident.id === selectedId,
  );

  const closeModal = () => selectIncident(null);

  function severityClass(severity: Severity): string {
    switch (severity) {
      case "critical":
        return "badge badge-critical";
      case "high":
        return "badge badge-high";
      case "medium":
        return "badge badge-medium";
      case "low":
      default:
        return "badge badge-low";
    }
  }

  console.log("Incidents", incidents);

  return (
    <>
      <ul className="incident-list">
        {incidents.map((incident) => (
          <IncidentItem
            key={incident.id}
            incident={incident}
            severityClass={severityClass}
            onClick={() => selectIncident(incident.id)}
          />
        ))}
      </ul>

      <Modal open={!!selectedId} onClose={closeModal} center>
        {selectedIncident && (
          <div style={{ padding: "20px" }}>
            <h2>{selectedIncident.title}</h2>
            <p>
              <strong>Severity: </strong>
              <span className={severityClass(selectedIncident.severity)}>
                {selectedIncident.severity.toUpperCase()}
              </span>
            </p>
            <p>
              <strong> Date & Time: </strong>
              {new Date(selectedIncident.timestamp).toLocaleString()}
            </p>
            <p>
              <strong> Description: </strong>
              {selectedIncident.description || "N/A"}
            </p>
          </div>
        )}
      </Modal>
    </>
  );
};

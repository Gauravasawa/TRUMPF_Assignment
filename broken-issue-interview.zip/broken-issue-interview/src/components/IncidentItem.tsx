import React from "react";
import type { Severity } from "../api/incidents";

export type IncidentListItem = {
  id: string;
  title: string;
  severity: Severity;
  timestamp: string;
};

type Props = {
  incident: IncidentListItem;
  onClick?: () => void;
  severityClass: (severity: Severity) => string;
};

export const IncidentItem: React.FC<Props> = ({
  incident,
  onClick,
  severityClass,
}) => {
  return (
    <li className="incident-item" onClick={onClick}>
      <div>
        <strong>{incident.title}</strong>
      </div>
      <div>
        <span className={severityClass(incident.severity)}>
          {incident.severity.toUpperCase()}
        </span>
        <span>{new Date(incident.timestamp).toLocaleString()}</span>
      </div>
    </li>
  );
};
